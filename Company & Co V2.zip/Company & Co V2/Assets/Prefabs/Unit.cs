﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unit : MonoBehaviour
{
    public Tile tile { get; protected set; }
    public Direction dir;

    public void Place(Tile target)
    {
        //Vérifie que l'ancienne location de Tile ne pointe pas sur l'unité
        if (tile != null && tile.content == gameObject)
            tile.content = null;
    }

    public void Match()
    {
        transform.localPosition = tile.center;
        transform.localEulerAngles = dir.ToEuler();
    }
}
